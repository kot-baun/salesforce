# salesforce
salesforce test

All tests are written in IntelegyIdea, the database dialect is h2, Java version 11 with the Lombok extension.

<b>src/Resources/SQL_requests</b> stores database queries (tasks 1 and 2)

<b>src/Main/Task3</b> stores solution for Task 3

<b>src/Main/Task4</b> ProductList store solution for task 4

<b>src/Main/Task4/Test_Backend</b> store solution for task 5
